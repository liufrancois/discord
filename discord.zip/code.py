from discord import client
import requests, sched, time, discord
from discord.ext import commands, tasks
import asyncio

bot = commands.Bot(command_prefix = "^")


@bot.event
async def on_ready():
	print("Ready !")

@bot.command()
async def mptime(ctx, timee, texte):
    timee = int(timee)
    timee=timee*60
    time.sleep(timee)
    await ctx.author.send(texte)

bot.run('token')